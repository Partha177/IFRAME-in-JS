window.addEventListener("load", function() {
  console.log("j2");
  

});

//receive url as message
window.addEventListener('message',function(event) {
	
	
	tmpUrl = event.data;
	
	//display url in iFrame
	 document.getElementById("if1").src = tmpUrl;
	
},false);
