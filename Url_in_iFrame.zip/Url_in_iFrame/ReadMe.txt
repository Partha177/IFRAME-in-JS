
About App

///////////////////////////////////////////////////////////
Name:URL_in_iFrame
Description: To display a URL in iFrame with scrolling enabled.
///////////////////////////////////////////////////////////


Permissions : No special permissions are required. The following code Will work for all types of app - priviliged/certified.




////////////////////////////////////////////////////////////
Sample Code : 



// in file - app.js




//send the url as a message to 1.html




function sendurl(url)
{
  var myPopup = window.open('1.html');
      
     var origin = document.location.protocol + '//' + document.location.host;
    var myVar =  setInterval(function(){
      myPopup.postMessage(url,origin);
        clearInterval(myVar);
      },2000);
     
}


// use keypress to decide which URL is to be sent


document.addEventListener('keydown', (event) => {
  const keyName = event.key;
  
  if(keyName == '1')
    {
      var url = "http://m.timesofindia.com/india/annoyed-sc-orders-auction-of-saharas-pricey-aamby-valley-property/articleshow/58220977.cms";
      sendurl(url);
     
    }
    
  if(keyName == '2')
    {
      var url = "http://m.timesofindia.com/world/us/use-diplomacy-not-proxies-us-nsa-to-pakistan/articleshow/58220689.cms";
      sendurl(url);
    }
  if(keyName == '3')
    {
      var url = "http://m.timesofindia.com/india/mumbai-chennai-and-hyderabad-airports-put-on-hijack-alert/articleshow/58204050.cms?utm_source=TOInewHP_TILwidget&utm_medium=ABtest&utm_campaign=TOInewHP";
      sendurl(url);
    }
  
}, false);


//in file - 2.html


window.addEventListener('message',function(event) {
	
	
	tmpUrl = event.data;
	
	//display url in iFrame
	 document.getElementById("if1").src = tmpUrl;
	
},false);



////////////////////////////////////////////////////////////