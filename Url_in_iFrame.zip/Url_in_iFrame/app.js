window.addEventListener("load", function() {
  console.log("Url in iFrame");
});

function sendurl(url) {
  var myPopup = window.open("1.html");
  //send the url as a message to 1.html
  var origin = document.location.protocol + "//" + document.location.host;
  var myVar = setInterval(function() {
    myPopup.postMessage("aaa.html", origin);
    clearInterval(myVar);
  }, 2000);
}

// use keypress to decide which URL is to be sent
document.addEventListener(
  "keydown",
  event => {
    const keyName = event.key;

    if (keyName == "1") {
      var url =
        "http://m.timesofindia.com/india/annoyed-sc-orders-auction-of-saharas-pricey-aamby-valley-property/articleshow/58220977.cms";
      sendurl(url);
    }

    if (keyName == "2") {
      var url =
        "http://m.timesofindia.com/world/us/use-diplomacy-not-proxies-us-nsa-to-pakistan/articleshow/58220689.cms";
      sendurl(url);
    }
    if (keyName == "3") {
      var url =
        "http://m.timesofindia.com/india/mumbai-chennai-and-hyderabad-airports-put-on-hijack-alert/articleshow/58204050.cms?utm_source=TOInewHP_TILwidget&utm_medium=ABtest&utm_campaign=TOInewHP";
      sendurl(url);
    }
  },
  false
);
